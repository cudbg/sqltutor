"""
The contents of this file are used in user-space by the application, and NOT in
databass for query compilation.  It loadsthe captured lineage and provides
convenient lineage query APIs.  

This probably makes sense to move into a databass/apis folder, but
we will leave it here for now..

TODO: move to APIs folder

"""
from ...baseops import Op, UnaryOp
from .lindex import Lindex
from collections import defaultdict
from collections.abc import Iterable

class IdentityDict(object):
  def __getitem__(self, key):
    return key

  def __str__(self):
    return "IdentityDict"

class Lineage(object):
  """
  This class provide convenient APIs for the application to query the captured lineage via
  Backward and Forward lineage queries.  

  It is initialized with the lindexes that were populated during query execution.
  """
  def __init__(self, plan):
    self.plan = plan
    self.lindexes = []
    self.materialized_ids = set()
    self.fws = defaultdict(dict)
    self.bws = defaultdict(dict)

    id2op = dict()
    ops = [self.plan]
    while ops:
      op = ops.pop()
      id2op[op.id] = op
      ops.extend(op.children())
    self.id2op = id2op

    self.intermediate_results = {}


    # columnar provenance for projections and groupbys
    self.col_lineage = dict()


  def add_intermediate_result(self, opid, data):
    self.intermediate_results[opid] = data

  def add_col_lineage(self, opid, col_lineage):
    """
    @opid id of operator
    @col_lineage a list the same size as op's output schema.
     each element is a list of indexes into the input schema.

       Run SELECT a, 1, a+b FROM T, where  T(a, b, c)
       col_lineage would be: [[0], [], [0,1]]
    """
    self.col_lineage[opid] = col_lineage

  def add(self, src_pair, dstid, idx, direction, typ):
    """
    Add a forward or backward lineage index 

    @src   (operator id, index). Represents input of operator.
           Index by default is 0.
           Index is 1 if src is right child of a join operator. 
    @dstid operator id.  Represents output of operator.
    @idx   lineage data structure
    @direction "fw" | "bw"
    @typ   Lindex.ONE | Lindex.N
    """
    if idx is None:
      idx = IdentityDict()

    srcid, index = src_pair
    self.lindexes.append((src_pair, dstid, idx, direction, typ))
    self.materialized_ids.update([srcid, dstid])
    if direction == "fw":
      self.fws[src_pair][dstid] = (idx, typ)
    elif direction == "bw":
      self.bws[dstid][src_pair] = (idx, typ)
    else:
      raise Exception("direction %s should be 'fw' or 'bw'" % direction)

    #print(self.id2op[srcid], srcid, "->", self.id2op[dstid], dstid, direction, typ)
    #print(idx)

  def find_bw_path(self, start, end):
    """
    Returns the sequence of backward lineage indexes that connects 
    the output of start to the input in end

    @start  operator id of ancestor (sink) operator
    @end  (operator id, index) of descendent (source) operator
    """
    if start not in self.bws:
      return None

    neighbors = self.bws[start]
    if end in neighbors:
      return [neighbors[end]]

    for neighbor in neighbors:
      opid, index = neighbor
      op = self.id2op[opid]
      if not op.children(): continue
      child = op.children()[index]

      # Neighbor represents the input of the "neighbor" operator
      # Translate into the output of the descendent pipeline breaker.
      #
      # If neighbor = (Join, 0), then we translate into A
      #
      #          Join
      #     Filter    B
      #      A    
      #

      # skip non-pipeline breakers
      while child and child.id not in self.bws:
        if not child.is_type(UnaryOp):
          break
          return None

        # if end was an operator that does not materialize
        # lineage, then it has the same lineage as neighbors[neighbor]
        if child.id == end[0]:
          return [neighbors[neighbor]]

        if not child.children(): break
        child = child.children()[0]

      if not child: 
        return None

      rest = self.find_bw_path(child.id, end)
      if rest:
        return [neighbors[neighbor]] + rest
    return None

  def back(self, oids, src_pair, dstid=None):
    """
    Given the output record ids of operator @dstid, 
    return rids in the @index'th input relation to @src 

    @src_pair (operator object or its ID, index)
    @dstid operator object or its ID.
           Assumed to be query output if None
    """
    if not isinstance(src_pair, tuple):
      src_pair = (src_pair, 0)
    if isinstance(src_pair[0], Op):
      src_pair = (src_pair[0].id, src_pair[1])
    if dstid is None:
      dstid = self.plan.id
    if isinstance(dstid, Op):
      dstid = dstid.id
    if not isinstance(oids, Iterable):
      oids = [oids]

    path = self.find_bw_path(dstid, src_pair)
    if not path:
      return None

    curoids = oids
    for lidx, typ in path:
      nextoids = []
      if typ == Lindex.ONE:
        for oid in curoids:
          nextoids.append(lidx[oid])
      else:
        for oid in curoids:
          nextoids.extend(lidx[oid])

      curoids = nextoids
    return curoids

  def find_fw_path(self, start, end):
    """
    Returns the sequence of backward lineage indexes that connects 
    the input of start to the output of end

    @start (operator id, index) of source operator
    @end operator id of sink operator
    """
    if start not in self.fws:
      return None

    neighbors = self.fws[start]
    if end in neighbors:
      return [neighbors[end]]
    
    for neighbor in neighbors:
      # Neighbor represents the output of the "neighbor" operator
      # Translate into the input of the ancestor pipeline breaker
      # If neighbor = A, then translate it into (Join, 0)
      #
      #          Join
      #     Filter    B
      #      A    
      #
      cur = self.id2op[neighbor]
      new_start = None
      while cur.p:
        index = cur.p.children().index(cur)
        # if it is in the fws index, then it is a pipeline breaker
        if (cur.p.id, index) in self.fws:
          new_start = (cur.p.id, index)
          break
        cur = cur.p
      if not new_start:
        return None

      rest = self.find_fw_path(new_start, end)
      if rest:
        #print self.id2op[neighbor]
        return [neighbors[neighbor]] + rest
    return None

  def forw(self, iids, src_pair, dstid=None):
    """
    Given input rids of the source operator, return rids of the
    outputs of the destination operator that are influenced by the
    input rids.  

    @dstid assumed to be query output if None
    """

    # src_pair refers to the source operator & input  relation we 
    # are referring to.  Default for unary ops is 0
    if not isinstance(src_pair, tuple):
      src_pair = (src_pair, 0)
    if isinstance(src_pair[0], Op):
      src_pair = (src_pair[0].id, src_pair[1])

    # default is root operator
    if dstid is None:
      dstid = self.plan.id
    if isinstance(dstid, Op):
      dstid = dstid.id
    if not isinstance(iids, Iterable):
      iids = [iids]

    path = self.find_fw_path(src_pair, dstid)
    if not path:
      return None

    curiids = iids
    for lidx, typ in path:
      nextiids = []
      if typ == Lindex.ONE:
        if isinstance(lidx, list):
          for iid in curiids:
            nextiids.append(lidx[iid])
        else:
          for iid in curiids:
            if iid not in lidx: continue
            nextiids.append(lidx[iid])
      else:
        if isinstance(lidx, list):
          for iid in curiids:
            nextiids.extend(lidx[iid])
        else:
          for iid in curiids:
            if iid not in lidx: continue
            nextiids.extend(lidx[iid])

      curiids = nextiids
    return curiids

  def lineage_pairs(self, opid):
    """
    @return list of [index, pairs] where 
      - index of the child operator 
      - pairs is a list of (output tuple id, input tuple id) 
    """
    neighbors = self.bws[opid]
    ret = []
    print("lineagepairs", opid, self.id2op[opid])
    for ((srcid, srcidx), (lindex, typ)) in neighbors.items():
      pairs = []
      if isinstance(lindex, IdentityDict):
        pairs = "Identity"
      elif typ == Lindex.ONE:
        pairs = list(enumerate(lindex))
      else:
        for oid, iids in enumerate(lindex):
          for iid in iids:
            pairs.append((oid, iid))
      ret.append([srcidx, pairs])
    ret.sort(key=lambda o: o[0])
    return ret

  @property
  def json_for_vis(self):
    return generate_lineage_for_vis(self)

  def __str__(self):
    ret = []
    for (srcid, index), dstid, idx, direction, typ in self.lindexes:
      src, dst = (self.id2op[srcid], self.id2op[dstid])
      typ = "N" if typ  == Lindex.N else "1"
      ret.append("# %s:%s %s(%s) -> %s" % (direction, typ, src, index, dst))
      ret.append(str(idx))
      ret.append("")
    return "\n".join(ret)





def generate_lineage_for_vis(lin):
  # rel op id -> [ (src, lineage pairs), ...]
  row_lineage = {} 

  # rel op id -> [ [attr idxs], ... ] 
  col_lineage = lin.col_lineage
  op_lineage = defaultdict(list)  # "root" is a special key that points to the root
  op_info = {}
  results = {}
  lineage_data = dict(
      row=row_lineage, 
      col=col_lineage,
      op=op_lineage,
      op_info=op_info,
      results=results,
      qstr="")

  # save intermediate results
  for save_opid, rows in lin.intermediate_results.items():
    opid = lin.id2op[save_opid].c.id
    op = lin.id2op[opid]
    schema = [a.aname for a in op.schema]
    results[opid] = dict(
      columns=schema,
      rows=list(rows)
    )

  # col lineage
  # ...


  # row lineage
  saves = [] # op for op in lin.id2op.values() if op.is_type("Save")]
  for op in lin.id2op.values():
    if not op.is_type("Save"):  continue
    if not op.c.is_type(["Filter", "Project"]): continue
    saves.append(op)

    lin_pairs = lin.lineage_pairs(op.id)
    for i in range(len(lin_pairs)):
      if lin_pairs[i][1] == "Identity":
        nrows = len(results[op.c.id])
        lin_pairs[i][1] = [(j,j) for j in range(nrows)]
    row_lineage[op.c.id] = lin_pairs

  saved_opids = set([s.c.id for s in saves])
  all_opids = set(lin.id2op.keys())
  nonsaved_opids = all_opids - saved_opids 
  nonsaved_opids -= set(op.id for op in saves)
  for opid in nonsaved_opids:
    lin_pairs = lin.lineage_pairs(opid)
    for i in range(len(lin_pairs)):
      if lin_pairs[i][1] == "Identity":
        nrows = len(results[op.id])
        lin_pairs[i][1] = [(j,j) for j in range(nrows)]
    row_lineage[opid] = lin_pairs


  # build query plan 
  for op in lin.id2op.values():
    if op.is_type("Save"): continue

    op_info[op.id] = dict(
      str=str(op),
      id=op.id,
      name=op.__class__.__name__,
      schema=[a.aname for a in op.schema]
    )

    if op.p.is_type("Save"):
      if not op.p.p:
        op_lineage["root"].append(op.id)
      else:
        op_lineage[op.p.p.id].append(op.id)
    elif not op.p:
      assert("root" not in op_lineage)
      op_lineage["root"].append(op.id)
    else:
      op_lineage[op.p.id].append(op.id)

  # Collect doesn't store any data, and its child is a Save,
  # so move root to its child's child
  rootid = op_lineage["root"][0]
  root = lin.id2op[rootid]
  op_lineage["root"] = [root.c.c.id]


  # compute query plan depth 
  root = op_info[op_lineage["root"][0]]
  root['depth'] = 0
  queue = [root]
  max_depth = 0
  while queue:
    cur = queue.pop()
    for opid in op_lineage[cur['id']]:
      op = op_info[opid]
      queue.append(op)
      op['depth'] = cur['depth'] + 1
      max_depth = max(max_depth, op['depth'])
  lineage_data['plan_depth'] = max_depth
  

  # verify that every op in query plan has interm results
  for opids in op_lineage.values():
    for opid in opids:
      assert opid in results, f"{lin.id2op[opid]} not found"

  return lineage_data


