from ...ops import Save
from ..debug import SaveTranslator
from ..scan import *
from ..root import *
from .translator import *

class PySaveTranslator(ScanTranslator,SinkTranslator,SaveTranslator,PyTranslator):
  def produce(self, ctx):
    if self.l_capture:
      ctx.add_line(f"# {self.op}")
      for lindex in self.lindexes:
        lindex.fw.initialize()
        lindex.bw.initialize()

    self.intermed_result = ctx.new_var("intermed_result")
    ctx.declare(self.intermed_result, "[]")
    ctx.request_vars(dict(row=None))

    self.child_translator.produce(ctx)

  def consume(self, ctx):
    self.v_irow = ctx['row']
    ctx.pop_vars()
    if self.l_capture:
      ctx.add_lines([
        f"{self.l_o} += 1",
        f"{self.intermed_result}.append(list({self.v_irow}.row))"
      ])
      for lindex in self.lindexes:
        lindex.fw.set_1(self.l_i, self.l_o)
        lindex.bw.append_1(self.l_i)

    ctx['row'] = self.v_irow
    self.parent_translator.consume(ctx)







