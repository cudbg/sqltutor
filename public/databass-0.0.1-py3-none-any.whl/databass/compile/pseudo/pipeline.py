from ...ops import *
from ..pipeline import *
from .translator import *
from .hashjoin import *
from .thetajoin import *
from .agg import *
from .project import *
from .scan import *
from .orderby import *
from .where import *
from .limit import *
from .root import *

class PseudoPipeline(Pipeline):

  def produce(self, ctx):
    ctx.add_line("# --- Pipeline %s ---" % self.id)
    self[-1].produce(ctx)
    ctx.add_line("")


class PseudoPipelines(Pipelines):
  def __init__(self, ast):
    super(PseudoPipelines, self).__init__(ast, PseudoPipeline)

  def create_bottom(self, op, *args):
    if op.is_type(GroupBy):
      return PseudoGroupByBottomTranslator(op, *args)
    if op.is_type(OrderBy):
      return PseudoOrderByBottomTranslator(op, *args)
    raise Exception("No Bottom Translator for %s" % op)

  def create_top(self, op, *args):
    if op.is_type(GroupBy):
      return PseudoGroupByTopTranslator(op, *args)
    if op.is_type(OrderBy):
      return PseudoOrderByTopTranslator(op, *args)
    raise Exception("No Top Translator for %s" % op)

  def create_left(self, op, *args):
    if op.is_type(HashJoin):
      return PseudoHashJoinLeftTranslator(op, *args)
    if op.is_type(ThetaJoin):
      return PseudoThetaJoinLeftTranslator(op, *args)
    raise Exception("No Left Translator for %s" % op)


  def create_right(self, op, *args):
    if op.is_type(HashJoin):
      return PseudoHashJoinRightTranslator(op, *args)
    if op.is_type(ThetaJoin):
      return PseudoThetaJoinRightTranslator(op, *args)
    raise Exception("No Right Translator for %s" % op)


  def create_normal(self, op, *args):
    translators = [
        (Project, PseudoProjectTranslator),
        (Limit, PseudoLimitTranslator),
        (Yield, PseudoYieldTranslator),
        (Print, PseudoPrintTranslator),
        (Collect, PseudoCollectTranslator),
        (SubQuerySource, PseudoSubQueryTranslator),
        (Scan, PseudoScanTranslator),
        (DummyScan, PseudoDummyScanTranslator),
        (Filter, PseudoFilterTranslator)
    ]

    for opklass, tklass in translators:
      if op.is_type(opklass):
        return tklass(op, *args)

    raise Exception("No Translator for %s" % op)
