from ...ops import GroupBy
from ..translator import *
from ..orderby import *
from .translator import *

class PseudoOrderByBottomTranslator(OrderByBottomTranslator, PseudoTranslator):

  def produce(self, ctx):
    """
    Define the buffer (list) that will store copies of every input row.
    We will also define a key function used to sort the buffered rows.
    The key function evaluates the order by expressions, then wraps 
    the results in an OBTuple that internally defines __cmp__.
    (see databass.util for OBTuple definition)

    """
    self.v_rows = ctx.new_var("ord_rows")
    self.v_keyf = ctx.new_var("ord_keyf")
    v_ordersort = ctx.new_var("ordersort")

    asc_args = ", ".join(["%s" % '1' if (e == "asc") else '-1'
      for (e) in self.op.ascdescs])
    ctx.set(self.v_rows, "[]")
    ctx.set(v_ordersort, "[%s]" % asc_args)

    # Generate key function for sort(key=?)
    with ctx.indent("def %s(arg):" % self.v_keyf):
      v_all = self.compile_exprs(ctx, self.op.order_exprs, "row")
      ctx.add_lines([
        "row = arg",
        "return OBTuple(({v_all},), {order})"
        ], v_all=", ".join(v_all), order=v_ordersort)


    ctx.request_vars(dict(row=None))
    self.child_translator.produce(ctx)

  def consume(self, ctx):
    """
    Actually populate buffer with copies of input rows
    """
    v_in = ctx['row']
    ctx.pop_vars()

    tmp = self.compile_new_tuple(ctx, self.op.schema, "ord_row")
    ctx.add_line("{rows}.append(dict({v_in}))",
      v_in=v_in, rows=self.v_rows)
    

class PseudoOrderByTopTranslator(OrderByTopTranslator, PseudoTranslator):

  def produce(self, ctx):
    """
    This is a pass-through producer.  
    Mainly handles lineage setup and cleanup
    """

    if self.child_translator:
      self.child_translator.produce(ctx)
    else:
      self.consume(ctx)


  def consume(self, ctx):
    """
    Sort buffered rows using special key function, then
    emit rows in sorted order.  
    """
    v_irow = ctx.new_var("ord_irow")

    ctx.add_line("{rows}.sort(key={keyf})", 
        rows=self.bottom.v_rows, keyf=self.bottom.v_keyf)

    with ctx.indent("for {irow} in {rows}:",
        irow=v_irow, rows=self.bottom.v_rows):

      ctx['row'] = v_irow
      self.parent_translator.consume(ctx)

