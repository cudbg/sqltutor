from ...ops import GroupBy
from ..translator import *
from ..root import *
from .translator import *

class PseudoSinkTranslator(SinkTranslator, PseudoTranslator):
  def initialize_lineage_indexes(self, ctx):
    pass
  def clean_prev_lineage_indexes(self):
    pass


  pass

class PseudoYieldTranslator(YieldTranslator, PseudoSinkTranslator):
  def consume(self, ctx):
    v_in = ctx['row']
    ctx.add_line("yield %s" % v_in)


class PseudoCollectTranslator(CollectTranslator, PseudoSinkTranslator):
  def produce(self, ctx):
    self.v_buffer = ctx.new_var("collect_buf")
    ctx.declare(self.v_buffer, "[]")

    self.child_translator.produce(ctx)
    ctx.returns("return {buf}", buf=self.v_buffer)

  def consume(self, ctx):
    v_in = ctx['row']

    v_tmp = self.compile_new_tuple(ctx, self.op.schema, "collect_tmp")
    ctx.add_lines([
      "{tup}.row = list({v_in}.row)", 
      "{buf}.append({tup})"],
      v_in=v_in, buf=self.v_buffer, tup=v_tmp)


class PseudoPrintTranslator(PrintTranslator, PseudoSinkTranslator):
  def consume(self, ctx):
    v_in = ctx['row']
    ctx.add_line("print(%s)" % v_in)




