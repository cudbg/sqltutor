import json
from ...ops import GroupBy
from ..translator import *
from ..orderby import *
from .translator import *

class PandasOrderByBottomTranslator(OrderByBottomTranslator, PandasTranslator):

  def produce(self, ctx):
    """
    Define the buffer (list) that will store copies of every input row.
    We will also define a key function used to sort the buffered rows.
    The key function evaluates the order by expressions, then wraps 
    the results in an OBTuple that internally defines __cmp__.
    (see databass.util for OBTuple definition)

    """
    ctx.request_vars(dict(df=None))
    self.child_translator.produce(ctx)

  def consume(self, ctx):
    """
    Actually populate buffer with copies of input rows
    """
    self.v_in = ctx['df']
    ctx.pop_vars()

    

class PandasOrderByTopTranslator(OrderByTopTranslator, PandasTranslator):

  def produce(self, ctx):
    """
    This is a pass-through producer.  
    Mainly handles lineage setup and cleanup
    """
    if self.child_translator:
      self.child_translator.produce(ctx)
    else:
      self.consume(ctx)


  def consume(self, ctx):
    """
    Sort buffered rows using special key function, then
    emit rows in sorted order.  
    """
    v_outdf = ctx.new_var("df")
    v_in = self.bottom.v_in

    aliases = []
    for i, e in enumerate(self.compile_exprs(ctx, self.op.order_exprs, v_in)):
      aliases.append(ctx.new_var("_orderkey_"))
      if self.bottom.op.ascdescs[i] != "asc":
        e = "-{e}".format(e=e)
      ctx.add_line("{df}['{alias}'] = {e}",
          df = v_in,
          alias=aliases[-1],
          e=e)
    
    ctx.add_line("{outdf} = {df}.sort_values({keys})",
        outdf=v_outdf,
        df=v_in,
        keys=json.dumps(aliases))

    ctx['df'] = v_outdf
    self.parent_translator.consume(ctx)

