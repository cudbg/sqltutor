from ..baseops import *

class Save(UnaryOp):
  def __iter__(self):
    return iter(self.c)

  def __str__(self):
    return f"{self.id} Save({str(self.c)})"

