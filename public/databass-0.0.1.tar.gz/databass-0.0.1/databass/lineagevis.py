from .db import Database
from .ops import *
from .parse_sql import parse
from .util import *
from .compile import *


class NpEncoder(json.JSONEncoder):
  def default(self, obj):
    if isinstance(obj, np.integer):
      return int(obj)
    if isinstance(obj, np.floating):
      return float(obj)
    if isinstance(obj, np.ndarray):
      return obj.tolist()
    return super(NpEncoder, self).default(obj)


def json_for_vis(q):
  db = Database.db()
  plan = Collect(parse(q).to_plan())
  cq = PyCompiledQuery(plan, AllLineagePolicy())
  results = cq(db)
  lin = cq.lineages[0]

  visjson = lin.json_for_vis
  visjson['qstr'] = q
  return visjson


def json_str_for_vis(q):
  visjson = json_for_vis(q)
  return json.dumps(visjson, cls=NpEncoder)

