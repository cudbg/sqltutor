from .db import Database
from .ops import *
from .parse_sql import parse
from .util import *
from .compile import *


class NpEncoder(json.JSONEncoder):
  def default(self, obj):
    if isinstance(obj, np.integer):
      return int(obj)
    if isinstance(obj, np.floating):
      return float(obj)
    if isinstance(obj, np.ndarray):
      return obj.tolist()
    return super(NpEncoder, self).default(obj)






def generate_lineage_for_vis(lin):
  # rel op id -> [ (src, lineage pairs), ...]
  row_lineage = {} 

  # rel op id -> [ [attr idxs], ... ] 
  col_lineage = lin.col_lineage

  # attributes used in filtering operations
  # op id -> [ (srctable, attrs), ... ]
  col_exprs = defaultdict(list)

  # "root" is a special key that points to the root
  op_lineage = defaultdict(list)  

  # information about indiv operators
  op_info = {}

  # intermediate results
  results = {}
  lineage_data = dict(
      row=row_lineage, 
      col=col_lineage,
      exprs=col_exprs,
      op=op_lineage,
      info=op_info,
      results=results,
      qstr="")

  # save intermediate results
  for save_opid, rows in lin.intermediate_results.items():
    opid = lin.id2op[save_opid].c.id
    op = lin.id2op[opid]
    schema = [a.aname for a in op.schema]
    results[opid] = dict(
      columns=schema,
      rows=list(rows)
    )

  # exprs
  for op in lin.id2op.values():
    if op.is_type("Save"): continue

    if op.is_type(Filter):
      cols = list(set([a.idx for a in op.cond.collect(Attr)]))
      col_exprs[op.id].append([0, cols])
    elif op.is_type(HashJoin):
      col_exprs[op.id].append([0, [op.join_attrs[0].idx]])
      col_exprs[op.id].append([1, [op.join_attrs[1].idx]])
    elif op.is_type(ThetaJoin):
      attrs = op.cond.collect(Attr)
      lcols = []
      rcols = []
      for a in attrs:
        if a.tablename == op.l.alias:
          lcols.append(a.idx)
        else:
          rcols.append(a.idx)
      col_exprs[op.id].append([0, lcols])
      col_exprs[op.id].append([1, rcols])


  # row lineage
  saves = [] # op for op in lin.id2op.values() if op.is_type("Save")]
  for op in lin.id2op.values():
    if not op.is_type("Save"):  continue
    if not op.c.is_type(["Filter", "Project"]): continue
    saves.append(op)

    lin_pairs = lin.lineage_pairs(op.id)
    for i in range(len(lin_pairs)):
      if lin_pairs[i][1] == "Identity":
        nrows = len(results[op.c.id])
        lin_pairs[i][1] = [(j,j) for j in range(nrows)]
    row_lineage[op.c.id] = lin_pairs

  saved_opids = set([s.c.id for s in saves])
  all_opids = set(lin.id2op.keys())
  nonsaved_opids = all_opids - saved_opids 
  nonsaved_opids -= set(op.id for op in saves)
  for opid in nonsaved_opids:
    lin_pairs = lin.lineage_pairs(opid)
    for i in range(len(lin_pairs)):
      if lin_pairs[i][1] == "Identity":
        nrows = len(results[op.id])
        lin_pairs[i][1] = [(j,j) for j in range(nrows)]
    row_lineage[opid] = lin_pairs


  # build query plan 
  for op in lin.id2op.values():
    if op.is_type("Save"): continue

    op_info[op.id] = dict(
      str=op.description(),
      id=op.id,
      name=op.__class__.__name__,
      schema=[a.aname for a in op.schema]
    )

    if op.p.is_type("Save"):
      if not op.p.p:
        op_lineage["root"].append(op.id)
      else:
        op_lineage[op.p.p.id].append(op.id)
    elif not op.p:
      assert("root" not in op_lineage)
      op_lineage["root"].append(op.id)
    else:
      op_lineage[op.p.id].append(op.id)

  # Collect doesn't store any data, and its child is a Save,
  # so move root to its child's child
  rootid = op_lineage["root"][0]
  root = lin.id2op[rootid]
  op_lineage["root"] = [root.c.c.id]


  # compute query plan depth 
  root = op_info[op_lineage["root"][0]]
  root['depth'] = 0
  queue = [root]
  max_depth = 0
  while queue:
    cur = queue.pop()
    for opid in op_lineage[cur['id']]:
      op = op_info[opid]
      queue.append(op)
      op['depth'] = cur['depth'] + 1
      max_depth = max(max_depth, op['depth'])
  lineage_data['plan_depth'] = max_depth
  

  # verify that every op in query plan has interm results
  for opids in op_lineage.values():
    for opid in opids:
      assert opid in results, f"{lin.id2op[opid]} not found"

  return lineage_data



def json_for_vis(q):
  db = Database.db()
  plan = Collect(parse(q).to_plan())
  cq = PyCompiledQuery(plan, AllLineagePolicy())
  results = cq(db)
  lin = cq.lineages[0]

  visjson = generate_lineage_for_vis(lin)
  visjson['qstr'] = q
  return visjson


def json_str_for_vis(q):
  visjson = json_for_vis(q)
  return json.dumps(visjson, cls=NpEncoder)

