from ..ops import Save
from .translator import *

class SaveTranslator(Translator):
  def __init__(self, *args, **kwargs):
    super(SaveTranslator, self).__init__(*args, **kwargs)
    self.data = []

  def produce(self, ctx):
    self.child_translator.produce(ctx)
