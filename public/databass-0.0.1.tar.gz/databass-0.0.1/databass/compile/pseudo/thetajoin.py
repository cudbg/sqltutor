from ...ops import ThetaJoin
from ..thetajoin import *
from .translator import *


class PseudoThetaJoinLeftTranslator(ThetaJoinLeftTranslator, PseudoTranslator):
  """
  Inner loop
  """
  def produce(self, ctx):
    ctx.request_vars(dict(row=None, table=None))
    self.child_translator.produce(ctx)

  def consume(self, ctx):
    self.v_lrow = ctx['row']
    ctx.pop_vars()

    self.parent_translator.consume(ctx)


class PseudoThetaJoinRightTranslator(ThetaJoinRightTranslator, PseudoRightTranslator):
  """
  Outer loop
  """

  def produce(self, ctx):
    # intermediate row
    self.v_irow = self.compile_new_tuple(ctx, self.op.schema, "theta_row")

    ctx.request_vars(dict(row=None, table=None))
    self.child_translator.produce(ctx)

  def consume(self, ctx):
    v_e = ctx.new_var("theta_cond")
    self.v_rrow = ctx['row']
    ctx.pop_vars()

    ctx.add_lines([
      "{irow}.update({left})",
      "{irow}.update({right})"
      ],
      irow=self.v_irow,
      left=self.left.v_lrow, 
      right=self.v_rrow
    )

    if str(self.op.cond) != "True":
      ctx.add_line("# ThetaJoin: if %s" % self.op.cond)
      v_e = self.compile_expr(ctx, self.op.cond, self.v_irow)

      with ctx.indent("if not {e}:", e=v_e):
        ctx.add_line("continue")

    ctx.add_line("")
    ctx['row'] = self.v_irow
    self.parent_translator.consume(ctx)


