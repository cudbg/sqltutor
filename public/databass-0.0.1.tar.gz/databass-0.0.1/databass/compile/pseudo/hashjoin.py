from ...ops import HashJoin
from ..hashjoin import *
from .translator import *


class PseudoHashJoinLeftTranslator(HashJoinLeftTranslator, PseudoTranslator):
  """
  The left translator scans the left child and populates the hash table
  """
  def produce(self, ctx):
    """
    Produce's job is to 
    1. allocate variable names and create hash table
    2. request the child operator's variable name for the current row
    3. ask the child to produce
    """
    self.v_ht = ctx.new_var("hjoin_ht")

    htinit = "defaultdict(list)"
    ctx.declare(self.v_ht, htinit)

    ctx.request_vars(dict(row=None))
    self.child_translator.produce(ctx)
    # solend


  def consume(self, ctx):
    """
    Given variable name for left row, compute left key and add a copy of the current row
    to the hash table
    """
    v_lkey = ctx.new_var("hjoin_lkey")
    v_lrow = ctx['row']
    ctx.pop_vars()
    
    ctx.add_line("# left probe key: %s" % self.op.join_attrs[0])
    v_lkey = self.compile_expr(ctx, self.op.join_attrs[0], v_lrow)
    ctx.add_line("{ht}[{lkey}].append(dict({lrow}))", 
        ht=self.v_ht,
        lkey=v_lkey,
        lrow=v_lrow)
    # solend


class PseudoHashJoinRightTranslator(HashJoinRightTranslator, PseudoRightTranslator):
  """
  The right translator scans the right child, and probes the hash table
  """

  def produce(self, ctx):
    """
    Allocates intermediate join tuple and asks the child to produce tuples (for the probe)
    """
    self.v_irow = self.compile_new_tuple(ctx, self.op.schema, "hjoin_row")
    ctx.request_vars(dict(row=None))
    self.child_translator.produce(ctx)


  def consume(self, ctx):
    """
    Given variable name for right row, 
    1. compute right key, 
    2. probe hash table, 
    3. create intermediate row to pass to parent's consume

    Note that because the hash key may not be unique, it's good hygiene
    to check the join condition again when probing.
    """
    # reference to the left translator's hash table variable
    v_ht = self.left.v_ht

    v_lrow = ctx.new_var("hjoin_lrow")
    v_rkey = ctx.new_var("hjoin_rkey")
    v_rrow = ctx['row']
    ctx.pop_vars()

    
    # compute probe key 
    ctx.add_line("# probe ht with: %s" % self.op.join_attrs[1])
    v_rkey = self.compile_expr(ctx, self.op.join_attrs[1], v_rrow)
    with ctx.indent("if {rkey} not in {ht}:", rkey=v_rkey, ht=v_ht):
      # continue probe loop if no match
      ctx.add_line("continue")

    # build intermediate row f
    ctx.add_line("{irow}.update({rrow})", irow=self.v_irow, rrow=v_rrow)

    cond = "for {lrow} in {group}:"
    with ctx.indent(cond, lrow=v_lrow, group="%s[%s]" % (v_ht, v_rkey)):
      ctx.add_line("{irow}.update({lrow})", irow=self.v_irow, lrow=v_lrow)
      ctx['row'] = self.v_irow
      self.parent_translator.consume(ctx)




