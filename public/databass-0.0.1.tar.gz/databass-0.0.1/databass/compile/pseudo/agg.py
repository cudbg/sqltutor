from ..translator import *
from ...exprs import *
from ..agg import *
from .translator import *


class PseudoGroupByBottomTranslator(GroupByBottomTranslator, PseudoTranslator):
  def produce(self, ctx):
    """
    Produce sets up the variables and hash table so that they can be populated by
    calling child's produce (which eventually calls self.consume). 
    
    """
    self.v_ht = ctx.new_var("hashidx")
    self.v_irow = self.compile_new_tuple(ctx, self.op.schema, "gb_irow")

    ctx.declare(self.v_ht, "defaultdict(list)")
    ctx.request_vars(dict(row=None))
    self.child_translator.produce(ctx)


  def consume(self, ctx):
    """
    Build hashtable

    For instance, if the query is:

        SELECT a-b, count(d)
        FROM data
        GROUP BY a+b-c

    Each hashtable entry contains the following information

    1. the hash probe key: e.g., hash of a+b-c
    2. values of attributes referenced in the grouping terms e.g., (a, b, c)
       see databass/ops/agg.py for their semantics
    3. the group of tuples
    """

    v_in = ctx['row']
    ctx.pop_vars()
    v_key = ctx.new_var("key")
    v_attrvals = ctx.new_var("attvals") # holds values of Attrs referenced in # grouping expression.
                                           # See self.group_attrs

    ctx.add_line("# Build hash table")

    
    exprs = self.op.group_attrs + self.op.group_exprs
    v_all = self.compile_exprs(ctx, exprs, v_in)
    v_gattrs = v_all[:len(self.op.group_attrs)]
    v_gexprs = v_all[len(self.op.group_attrs):]

    lines = [
      "{key} = hash(({exprs}))",
      "{ht}[{key}].append(dict({v_in}))"
    ]

    formatargs = dict(
      ht=self.v_ht,
      v_in = v_in, 
      key=v_key, 
      exprs=", ".join(v_gexprs)
    )
    ctx.add_lines(lines, **formatargs)

  
class PseudoGroupByTopTranslator(GroupByTopTranslator, PseudoTranslator):

  def produce(self, ctx):
    if self.child_translator:
      self.child_translator.produce(ctx)
    else:
      self.consume(ctx) 

  def consume(self, ctx):
    """
    Loop through populated hash table and construct output tuple per group.  
    After constructing the output tuple, pass it to the parent's consumer.
    Don't forget to tell the parent the variable name containing the tuple.
    """

    v_ht = self.bottom.v_ht
    v_bucket = ctx.new_var("gb_bucket")

    # loop through hash table to emit results and call parent's consume
    with ctx.indent("for {bucket} in {ht}.values():", bucket=v_bucket, ht=v_ht): 
      self.fill_output_row(ctx, v_bucket)

      ctx["row"] = self.bottom.v_irow
      self.parent_translator.consume(ctx)


  def fill_output_row(self, ctx, v_bucket):
    v_expr_result = None 
    grouping = "%s[0]" % v_bucket

    pairs = zip(self.op.aliases, self.op.project_exprs)
    newfields = []
    for i, (alias, e) in enumerate(pairs):

      if e.is_agg_expr():
        v_expr_result = self.compile_expr(ctx, e, v_bucket)
      else:
        v_expr_result = self.compile_expr(ctx, e, grouping)

      newfields.append((alias, v_expr_result))


    d = "dict({args})".format(
        args=", ".join(map(lambda p: "{0}={1}".format(*p), newfields))
    )
    ctx.add_line("{irow}.update({d})",
      irow=self.bottom.v_irow,
      d=d
    )
